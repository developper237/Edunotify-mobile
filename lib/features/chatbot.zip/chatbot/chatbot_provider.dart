import 'package:flutter_riverpod/flutter_riverpod.dart';
import '../../../core/api_client.dart';
import '../../../features/auth/auth_provider.dart';
import 'models/chat_message.dart';

// ══════════════════════════════════════════════════════════════════
// ÉTAT DU CHAT
// ══════════════════════════════════════════════════════════════════

class ChatState {
  final List<ChatMessage> messages;
  final bool isLoading;

  const ChatState({
    required this.messages,
    required this.isLoading,
  });

  factory ChatState.initial() => const ChatState(
    messages: [],
    isLoading: false,
  );

  ChatState copyWith({
    List<ChatMessage>? messages,
    bool? isLoading,
  }) =>
      ChatState(
        messages: messages ?? this.messages,
        isLoading: isLoading ?? this.isLoading,
      );
}

// ══════════════════════════════════════════════════════════════════
// PROVIDER
// ══════════════════════════════════════════════════════════════════

final chatProvider = StateNotifierProvider<ChatNotifier, ChatState>(
      (ref) => ChatNotifier(ref),
);

// ══════════════════════════════════════════════════════════════════
// NOTIFIER
// ══════════════════════════════════════════════════════════════════

class ChatNotifier extends StateNotifier<ChatState> {
  final Ref _ref;

  ChatNotifier(this._ref) : super(ChatState.initial());

  /// Charge l'historique persistant depuis PostgreSQL au démarrage de l'écran
  Future<void> loadHistory() async {
    final user = _ref.read(currentUserProvider);
    if (user == null) return;

    state = state.copyWith(isLoading: true);
    try {
      // CORRECTION : L'URL relative est juste '/api/chat/history' car la baseUrl est 'http://192.168.1.203:8085'
      final response = await ApiClient.getChatbot(
        '/api/chat/history',
        userId: user.id,
        role: user.role,
      );

      if (response is List) {
        final loadedMessages = response.map((data) => ChatMessage(
          id: data['id'].toString(),
          text: data['text'] as String,
          isUser: data['isUser'] as bool,
          createdAt: DateTime.parse(data['createdAt'] as String),
        )).toList();

        state = ChatState(messages: loadedMessages, isLoading: false);
      } else {
        state = state.copyWith(isLoading: false);
      }
    } catch (e, stack) {
      print('=== ❌ ERREUR CHARGEMENT HISTORIQUE ===');
      print(e);
      print(stack);
      state = state.copyWith(isLoading: false);
    }
  }

  /// Envoie un nouveau message et l'enregistre en arrière-plan
  Future<void> send(String text) async {
    if (text.trim().isEmpty) return;

    final user = _ref.read(currentUserProvider);
    if (user == null) return;

    // 1. Préparation et formatage de l'historique existant pour Gemini
    final List<Map<String, dynamic>> historyList = state.messages.map((msg) {
      return {
        'role': msg.isUser ? 'user' : 'model',
        'parts': [
          {'text': msg.text}
        ],
      };
    }).toList();

    // 2. Ajout du message de l'utilisateur immédiatement dans l'UI
    final userMessage = ChatMessage(
      id: DateTime.now().millisecondsSinceEpoch.toString(),
      text: text,
      isUser: true,
      createdAt: DateTime.now(),
    );

    state = state.copyWith(
      messages: [...state.messages, userMessage],
      isLoading: true,
    );

    try {
      // CORRECTION : L'URL relative pour le POST est '/api/chat'
      final resp = await ApiClient.postChatbot(
        '/api/chat',
        data: {
          'message': text,
          'history': historyList,
        },
        userId: user.id,
        role: user.role,
      );

      final replyText = resp['reply'] as String? ?? "Je n'ai pas compris la réponse.";

      final botMessage = ChatMessage(
        id: DateTime.now().millisecondsSinceEpoch.toString(),
        text: replyText,
        isUser: false,
        createdAt: DateTime.now(),
      );

      state = state.copyWith(
        messages: [...state.messages, botMessage],
        isLoading: false,
      );
    } catch (e, stack) {
      print('=== ❌ ERREUR ENVOI MESSAGE ===');
      print(e);
      print(stack);
      _addError(
        "Désolé, je n'arrive pas à joindre le serveur SmartCampus. "
            "Vérifie ta connexion.",
      );
    }
  }

  void _addError(String msg) {
    final errorMessage = ChatMessage(
      id: DateTime.now().millisecondsSinceEpoch.toString(),
      text: msg,
      isUser: false,
      createdAt: DateTime.now(),
    );
    state = state.copyWith(
      messages: [...state.messages, errorMessage],
      isLoading: false,
    );
  }

  void clearMessages() {
    state = ChatState.initial();
  }
}